package com.bank.model;

public enum Network {
    VISA, 
    MASTERCARD, 
    AMERICAN_EXPRESS, 
    DISCOVER
} 