package com.bank.model;

public enum AssetType {
    CASH, 
    GOLD, 
    METAL, 
    INVESTMENT, 
    LOAN, 
    PROPERTY
} 