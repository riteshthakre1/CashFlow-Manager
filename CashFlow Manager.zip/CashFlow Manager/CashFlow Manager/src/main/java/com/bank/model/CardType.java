package com.bank.model;

public enum CardType {
    DEBIT, 
    CREDIT, 
    PREPAID, 
    PURCHASES
} 