package com.bank.model;

public enum Role {
    TELLER, 
    BANKER, 
    LOAN_PROCESSOR
} 