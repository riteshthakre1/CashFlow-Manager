package com.bank.model;

public enum AccountType {
    INDIVIDUAL, 
    BUSINESS
} 